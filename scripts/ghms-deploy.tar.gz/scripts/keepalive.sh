#!/bin/bash
cd /home/z/my-project/ghms-clone
export NODE_OPTIONS="--max-old-space-size=384"
export HOSTNAME=0.0.0.0
export NODE_ENV=production

# Use standalone server (output: "standalone" in next.config.ts)
SERVER=".next/standalone/server.js"

while true; do
  if [ -f "$SERVER" ]; then
    node "$SERVER" -p 3000 2>&1 | tee -a /tmp/ghms-keepalive.log
  else
    echo "$(date): Standalone server not found at $SERVER, falling back to next start" >> /tmp/ghms-keepalive.log
    npx next start -p 3000 2>&1 | tee -a /tmp/ghms-keepalive.log
  fi
  EXIT_CODE=$?
  echo "$(date): Server exited with code $EXIT_CODE, restarting in 2s..." >> /tmp/ghms-keepalive.log
  sleep 2
done